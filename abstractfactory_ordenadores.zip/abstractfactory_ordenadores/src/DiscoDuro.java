package src;
public interface DiscoDuro {
    String getDiscoDuroInfo();
}
