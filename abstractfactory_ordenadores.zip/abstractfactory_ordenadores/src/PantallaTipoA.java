package src;
public class PantallaTipoA implements Pantalla {
    @Override
    public String getPantallaInfo() {
        return "15.6 pulgadas, Full HD";
    }
}
