package src;
public class DiscoDuroTipoA implements DiscoDuro {
    @Override
    public String getDiscoDuroInfo() {
        return "SSD 256GB";
    }
}

