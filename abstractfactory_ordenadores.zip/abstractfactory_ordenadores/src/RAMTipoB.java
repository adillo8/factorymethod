package src;
public class RAMTipoB implements RAM {
    @Override
    public String getRAMInfo() {
        return "16GB DDR4";
    }
}
