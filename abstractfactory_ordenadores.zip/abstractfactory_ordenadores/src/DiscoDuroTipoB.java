package src;
public class DiscoDuroTipoB implements DiscoDuro {
    @Override
    public String getDiscoDuroInfo() {
        return "SSD 512GB";
    }
}
