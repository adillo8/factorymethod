package src;
public class RAMTipoA implements RAM {
    public String getRAMInfo() {
        return "8GB DDR4";
    }
}

