package src;
public class RAMTipoC implements RAM {
    @Override
    public String getRAMInfo() {
        return "32GB DDR4";
    }
}
