package src;
public class PantallaTipoB implements Pantalla {
    @Override
    public String getPantallaInfo() {
        return "17.3 pulgadas, Full HD";
    }
}
