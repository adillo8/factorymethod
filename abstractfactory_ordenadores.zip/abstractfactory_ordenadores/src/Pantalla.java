package src;
public interface Pantalla {
    String getPantallaInfo();
}
