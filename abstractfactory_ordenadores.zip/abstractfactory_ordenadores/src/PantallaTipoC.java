package src;
public class PantallaTipoC implements Pantalla {
    @Override
    public String getPantallaInfo() {
        return "17.3 pulgadas, 4K UHD";
    }
}
