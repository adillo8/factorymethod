package src;
public interface RAM {
    String getRAMInfo();
}
