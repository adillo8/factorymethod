package src;
public class DiscoDuroTipoC implements DiscoDuro {
    @Override
    public String getDiscoDuroInfo() {
        return "HDD 1TB";
    }
}

